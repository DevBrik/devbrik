package sn.devbrik.backend.auth.service;

import org.springframework.http.HttpStatus;
import sn.devbrik.backend.common.ApiException;

/**
 * Fabrique des erreurs du module auth (codes du catalogue 11.7).
 * Seul fichier du module qui connaît le constructeur d'ApiException : un seul point à adapter.
 */
public final class ErreursAuth {

    private ErreursAuth() {
    }

    public static ApiException requeteInvalide(String message) {
        return new ApiException(HttpStatus.BAD_REQUEST, "REQUETE_INVALIDE", message);
    }

    public static ApiException pseudoReserve() {
        return new ApiException(HttpStatus.BAD_REQUEST, "PSEUDO_RESERVE",
                "Ce pseudo est réservé. Choisissez-en un autre.");
    }

    public static ApiException pseudoDejaUtilise() {
        return new ApiException(HttpStatus.CONFLICT, "PSEUDO_DEJA_UTILISE",
                "Ce pseudo est déjà utilisé.");
    }

    /** Message volontairement identique pour « pseudo inconnu » et « mot de passe faux ». */
    public static ApiException identifiantsInvalides() {
        return new ApiException(HttpStatus.UNAUTHORIZED, "IDENTIFIANTS_INVALIDES",
                "Pseudo ou mot de passe incorrect.");
    }

    public static ApiException nonAuthentifie() {
        return new ApiException(HttpStatus.UNAUTHORIZED, "NON_AUTHENTIFIE",
                "Authentification requise.");
    }

    public static ApiException motDePasseIncorrect() {
        return new ApiException(HttpStatus.BAD_REQUEST, "MOT_DE_PASSE_INCORRECT",
                "Le mot de passe est incorrect.");
    }

    public static ApiException suppressionAdminInterdite() {
        return new ApiException(HttpStatus.FORBIDDEN, "SUPPRESSION_ADMIN_INTERDITE",
                "Un compte administrateur ne peut pas être supprimé.");
    }
}
